package com.apptec.registrateapp.presenter;

public interface NotificationPresenter {


    void showNotNewNotificationsMessage();



    void detachView();
    void detachJob();



}
