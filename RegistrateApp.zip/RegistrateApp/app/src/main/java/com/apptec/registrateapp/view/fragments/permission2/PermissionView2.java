package com.apptec.registrateapp.view.fragments.permission2;

public interface PermissionView2 {
}
