package com.apptec.registrateapp.presenter;

public class HomePresenterImpl {
}
