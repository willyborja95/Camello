package com.apptec.registrateapp.presenter;

public interface HomePresenter {
}
