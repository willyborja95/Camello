package com.apptec.registrateapp.repository.localdatabase.daos;

import androidx.room.Dao;

@Dao
public interface CompanyDao {
    /**
     * Dao fro company
     * @return
     */

}
