package com.apptec.registrateapp.models;

public class UpdatePushTokenBody {

    private String pushToken;

    public String getPushToken() {
        return pushToken;
    }

    public void setPushToken(String pushToken) {
        this.pushToken = pushToken;
    }
}
