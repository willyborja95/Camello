package com.apptec.registrateapp.presenter;

public class PermissionPresenterImpl implements PermissionPresenter{
}
