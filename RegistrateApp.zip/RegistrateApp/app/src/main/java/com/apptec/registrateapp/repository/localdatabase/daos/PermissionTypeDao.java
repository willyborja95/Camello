package com.apptec.registrateapp.repository.localdatabase.daos;

import androidx.room.Dao;

@Dao
public interface PermissionTypeDao {
    /**
     * Dao fro PermissionType
     * @return
     */

}
