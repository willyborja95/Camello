package com.apptec.registrateapp.interactor;

public class HomeInteractorImpl implements HomeInteractor {
}
