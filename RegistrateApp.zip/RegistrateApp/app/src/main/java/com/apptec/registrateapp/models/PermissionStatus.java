package com.apptec.registrateapp.models;

public enum PermissionStatus {
    Revisando,
    Aprobado,
    Rechazado
}
