package com.apptec.registrateapp.interactor;

public class PermissionInteractorView implements PermissionInteractor{
}
