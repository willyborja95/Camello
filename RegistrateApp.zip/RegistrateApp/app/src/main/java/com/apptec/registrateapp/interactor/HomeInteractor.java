package com.apptec.registrateapp.interactor;

public interface HomeInteractor {
}
