<p align="center">
   <a href="https://github.com/willyborja95/RegistrateApp/releases">
    <img src="https://img.shields.io/badge/release-v2.0.1-green" alt="Latest Stable Version" />
  </a>
   <a href="https://developer.android.com/about/versions/marshmallow/android-6.0">
    <img src="https://img.shields.io/badge/API-%2B23-yellow" alt="Min Sdk Version" />
  </a>
</p>

# Registrate App

This app in build on Java using the Android Studio IDE.

The pattern used now is the MVVM (Model View ViewModel)

You can search about it on: https://developer.android.com/jetpack

The files are organized according this components in packages with the same name.
